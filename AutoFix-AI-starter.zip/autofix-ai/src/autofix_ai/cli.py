"""Command-line interface."""

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from autofix_ai.analyzer import scan_project

app = typer.Typer(help="AutoFix AI — local-first Python debugging assistant.")
console = Console()


@app.command()
def scan(project: Path = typer.Argument(..., exists=True, file_okay=False, dir_okay=True)):
    """Scan a Python project for syntax errors (read-only; does not execute code)."""
    try:
        report = scan_project(project)
    except (FileNotFoundError, NotADirectoryError) as exc:
        raise typer.BadParameter(str(exc)) from exc

    console.rule("[bold blue]AutoFix AI — Project Scan")
    console.print(f"Project: [cyan]{report.root}[/cyan]")
    console.print(f"Python files scanned: [bold]{report.python_files}[/bold]")
    console.print(f"Syntax errors: [bold red]{report.syntax_error_count}[/bold red]")

    if report.diagnostics:
        table = Table("File", "Line", "Type", "Message")
        for item in report.diagnostics:
            table.add_row(
                str(item.path),
                str(item.line or "-"),
                item.kind,
                item.message,
            )
        console.print(table)
        raise typer.Exit(code=1)

    console.print("[bold green]No syntax errors found.[/bold green]")


if __name__ == "__main__":
    app()
