"""AutoFix AI: local-first autonomous debugging and repair."""

__version__ = "0.1.0"
