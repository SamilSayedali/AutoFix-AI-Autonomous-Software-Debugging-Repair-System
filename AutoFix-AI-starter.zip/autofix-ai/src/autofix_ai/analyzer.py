"""Static analysis that never imports or executes target project code."""

import ast
from pathlib import Path

from autofix_ai.models import Diagnostic, ScanReport
from autofix_ai.scanner import discover_python_files


def analyze_file(path: Path, project_root: Path) -> list[Diagnostic]:
    """Parse one Python file and report syntax errors."""
    try:
        source = path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        return [Diagnostic(
            path=path.relative_to(project_root),
            kind="read_error",
            message=f"Could not decode as UTF-8: {exc}",
            severity="warning",
        )]
    except OSError as exc:
        return [Diagnostic(
            path=path.relative_to(project_root),
            kind="read_error",
            message=f"Could not read file: {exc}",
            severity="warning",
        )]

    try:
        ast.parse(source, filename=str(path))
    except SyntaxError as exc:
        return [Diagnostic(
            path=path.relative_to(project_root),
            kind="syntax_error",
            message=exc.msg,
            line=exc.lineno,
        )]
    return []


def scan_project(root: Path) -> ScanReport:
    """Scan Python files and return syntax diagnostics without executing them."""
    root = root.resolve()
    python_files = list(discover_python_files(root))
    diagnostics: list[Diagnostic] = []

    for path in python_files:
        diagnostics.extend(analyze_file(path, root))

    return ScanReport(
        root=root,
        files_scanned=len(python_files),
        python_files=len(python_files),
        diagnostics=diagnostics,
    )
