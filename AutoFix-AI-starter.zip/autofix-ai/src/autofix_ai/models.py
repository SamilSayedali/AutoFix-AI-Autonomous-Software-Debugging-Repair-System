"""Typed data models shared by AutoFix AI components."""

from pathlib import Path
from pydantic import BaseModel, Field


class Diagnostic(BaseModel):
    """A finding produced while inspecting a source file."""

    path: Path
    kind: str
    message: str
    line: int | None = None
    severity: str = "error"


class ScanReport(BaseModel):
    """Summary of a project scan."""

    root: Path
    files_scanned: int = 0
    python_files: int = 0
    diagnostics: list[Diagnostic] = Field(default_factory=list)

    @property
    def syntax_error_count(self) -> int:
        return sum(item.kind == "syntax_error" for item in self.diagnostics)
