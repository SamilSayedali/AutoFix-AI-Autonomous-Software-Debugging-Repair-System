"""Read-only project discovery."""

from pathlib import Path
from collections.abc import Iterator

IGNORED_DIRS = {
    ".git", ".venv", "venv", "__pycache__", ".mypy_cache",
    ".pytest_cache", ".ruff_cache", "node_modules", "dist", "build",
}


def discover_python_files(root: Path) -> Iterator[Path]:
    """Yield Python files beneath root, excluding common generated directories."""
    root = root.resolve()
    if not root.exists():
        raise FileNotFoundError(f"Project path does not exist: {root}")
    if not root.is_dir():
        raise NotADirectoryError(f"Project path is not a directory: {root}")

    for path in sorted(root.rglob("*.py")):
        if any(part in IGNORED_DIRS for part in path.relative_to(root).parts):
            continue
        if path.is_file():
            yield path
