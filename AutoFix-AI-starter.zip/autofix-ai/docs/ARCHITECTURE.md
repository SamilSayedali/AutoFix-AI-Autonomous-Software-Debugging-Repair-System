# Architecture (v0.1)

```text
CLI
 |
 v
Project Scanner ----> Static Analyzer (AST)
                            |
                            v
                       Diagnostics
                            |
                 [Phase 3: Local LLM]
                            |
                 [Phase 4: Repair Planner]
                            |
                 [Phase 5: Isolated Runner]
                            |
                 [Phase 6: Regression Tests]
                            |
                       Final Report
```

## Trust boundaries

1. Treat every scanned repository as untrusted input.
2. Static analysis must not import target modules.
3. The repair engine will write only to a disposable working copy.
4. Never run generated code on the host.
5. Sandbox execution must disable networking, drop capabilities, avoid privileged mode, set CPU/memory/PID/time limits, and mount only the disposable workspace.
6. Applying a patch to the original project must require explicit user approval.

## Initial design choices

- Python AST for deterministic syntax checks.
- Pydantic models for typed diagnostics.
- Typer + Rich for a usable CLI.
- Ollama as an optional local model runtime in a later phase.
- pytest for regression validation.
