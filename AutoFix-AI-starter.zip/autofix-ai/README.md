# AutoFix AI

**Autonomous Software Debugging & Repair System** — a local-first Python project.

AutoFix AI is being developed in phases. The first release establishes a safe project-scanning and static-analysis foundation. Later phases add a local language model, controlled patch generation, isolated execution, regression testing, and a dashboard.

## Current status

- [x] Project structure and packaging
- [x] Python project scanner
- [x] AST-based syntax validation
- [x] Basic diagnostic report
- [x] CLI and unit tests
- [ ] Local Ollama reasoning engine
- [ ] Patch generation and review
- [ ] Docker execution sandbox
- [ ] Regression-test validation
- [ ] Streamlit dashboard

> **Safety:** The current version only reads project files and reports findings. It does not execute or modify the target project. Do not run untrusted code outside a properly isolated environment. Docker isolation will be added in a later phase and must be configured with network access disabled, read-only mounts where possible, resource limits, and no privileged mode.

## Requirements

- Python 3.10+
- Windows, macOS, or Linux

## Setup

```bash
git clone https://github.com/YOUR_USERNAME/AutoFix-AI.git
cd AutoFix-AI

python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
# source .venv/bin/activate

python -m pip install --upgrade pip
pip install -e ".[dev]"
```

## Run

```bash
autofix scan ./path/to/python-project
```

Or:

```bash
python -m autofix_ai.cli scan ./path/to/python-project
```

## Example output

```text
AutoFix AI — Project Scan
Files scanned: 4
Python files: 3
Syntax errors: 1
```

## Development

```bash
pytest
ruff check .
```

## Roadmap

1. Static project intelligence
2. Local LLM reasoning via Ollama
3. Patch proposals with human review
4. Isolated execution and test validation
5. Repair loop with bounded retries
6. Streamlit dashboard and reproducible benchmarks

## Research direction

A key engineering goal is to measure repair quality rather than merely generate code. Planned metrics include:
- repair success rate
- regression rate
- tests passed before and after repair
- number of repair attempts
- execution time

## License

MIT
