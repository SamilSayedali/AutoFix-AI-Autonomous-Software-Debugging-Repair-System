from pathlib import Path

from autofix_ai.analyzer import scan_project


def test_scan_finds_syntax_error(tmp_path: Path):
    (tmp_path / "broken.py").write_text("def broken(:\n    pass\n", encoding="utf-8")

    report = scan_project(tmp_path)

    assert report.python_files == 1
    assert report.syntax_error_count == 1
    assert report.diagnostics[0].line == 1


def test_scan_accepts_valid_python(tmp_path: Path):
    (tmp_path / "valid.py").write_text("answer = 42\n", encoding="utf-8")

    report = scan_project(tmp_path)

    assert report.syntax_error_count == 0
    assert report.diagnostics == []
