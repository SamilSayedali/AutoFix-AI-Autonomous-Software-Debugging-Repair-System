from pathlib import Path

from autofix_ai.scanner import discover_python_files


def test_discover_python_files_ignores_virtualenv(tmp_path: Path):
    (tmp_path / "app.py").write_text("print('ok')", encoding="utf-8")
    ignored = tmp_path / ".venv"
    ignored.mkdir()
    (ignored / "ignored.py").write_text("bad", encoding="utf-8")

    found = list(discover_python_files(tmp_path))
    assert [item.name for item in found] == ["app.py"]
